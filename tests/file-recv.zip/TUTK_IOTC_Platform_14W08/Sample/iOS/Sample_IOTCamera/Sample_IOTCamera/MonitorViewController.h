//
//  AppMonitorViewController.h
//  IOTCamSample
//
//  Created by Cloud Hsiao on 12/7/17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <IOTCamera/AVIOCTRLDEFs.h>
#import <IOTCamera/Camera.h>
#import <IOTCamera/Monitor.h>

@interface MonitorViewController : UIViewController <CameraDelegate>
{
    Camera *camera;
    Monitor *monitor;
}

@property (nonatomic, retain) Camera *camera;
@property (nonatomic, retain) IBOutlet Monitor *monitor;


@end
