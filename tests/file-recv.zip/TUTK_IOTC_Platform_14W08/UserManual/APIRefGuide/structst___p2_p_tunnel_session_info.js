var structst___p2_p_tunnel_session_info =
[
    [ "nAuthDataLen", "structst___p2_p_tunnel_session_info.html#a1c9302b9c0a3852ed814ef75da621fa4", null ],
    [ "nMode", "structst___p2_p_tunnel_session_info.html#ae3242b9b0709d103c25524ab9887c5b6", null ],
    [ "nNatType", "structst___p2_p_tunnel_session_info.html#a64315523ef3b110bd9008acc7f596c2e", null ],
    [ "nRemotePort", "structst___p2_p_tunnel_session_info.html#a998f4da89525c9eaa547de5e2e31fa29", null ],
    [ "nSID", "structst___p2_p_tunnel_session_info.html#aa0ffd04e24691668fc0b28715304767d", null ],
    [ "nVersion", "structst___p2_p_tunnel_session_info.html#aefe9b43a822e549eb0dd720e1419cd9d", null ],
    [ "pAuthData", "structst___p2_p_tunnel_session_info.html#a65ffa7ac32528bed4f4d01ca56ff038f", null ],
    [ "szRemoteIP", "structst___p2_p_tunnel_session_info.html#af50a5fbe7262a0c1045d72fdf78cb5ce", null ]
];