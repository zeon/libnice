var searchData=
[
  ['bufsizeinrecvqueue',['BufSizeInRecvQueue',['../structst___r_d_t___status.html#a77a2bd6dd9bd31245c083b4f426f4eba',1,'st_RDT_Status']]],
  ['bufsizeinsendqueue',['BufSizeInSendQueue',['../structst___r_d_t___status.html#a0f4127a69d47042b654e9bf5ba6719d0',1,'st_RDT_Status']]]
];
