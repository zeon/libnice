var searchData=
[
  ['iotc_5farbitrary_5fmode',['IOTC_ARBITRARY_MODE',['../_i_o_t_c_a_p_is_8h.html#a42a1181e1dc2b7d36c00520f8ec074aea54e03a4c753d8b3474194e8c4fbdb985',1,'IOTCAPIs.h']]],
  ['iotc_5fnon_5fsecure_5fmode',['IOTC_NON_SECURE_MODE',['../_i_o_t_c_a_p_is_8h.html#a42a1181e1dc2b7d36c00520f8ec074aea750bdae0d782e4215faf632da9412c0b',1,'IOTCAPIs.h']]],
  ['iotc_5fsecure_5fmode',['IOTC_SECURE_MODE',['../_i_o_t_c_a_p_is_8h.html#a42a1181e1dc2b7d36c00520f8ec074aead2e4f327257725d70e225039e51e0fcf',1,'IOTCAPIs.h']]],
  ['iotype_5finner_5fsnd_5fdata_5fdelay',['IOTYPE_INNER_SND_DATA_DELAY',['../_a_v_a_p_is_8h.html#aa1aaee8df70d76b158c0206c1b1118aca3f380f12544dee5088c571e621d39702',1,'AVAPIs.h']]],
  ['iotype_5fuser_5fdefined_5fstart',['IOTYPE_USER_DEFINED_START',['../_a_v_a_p_is_8h.html#aa1aaee8df70d76b158c0206c1b1118aca88ac3bc8981f9146ba8602beec89216b',1,'AVAPIs.h']]]
];
