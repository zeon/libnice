var searchData=
[
  ['remoteip',['RemoteIP',['../structst___s_info.html#a1c84b8d0e8d286931056c3278b0a37b5',1,'st_SInfo']]],
  ['remoteport',['RemotePort',['../structst___s_info.html#abe3861fbe0a0755f020347a4e624d63d',1,'st_SInfo']]],
  ['reserved',['Reserved',['../structst___lan_search_info.html#a9da2be76809eedd60a7543c651fd25ab',1,'st_LanSearchInfo::Reserved()'],['../structst___lan_search_info2.html#a9da2be76809eedd60a7543c651fd25ab',1,'st_LanSearchInfo2::Reserved()']]],
  ['rx_5fpacketcount',['RX_Packetcount',['../structst___s_info.html#a374bc2765cf532d173155426aefba4ec',1,'st_SInfo']]]
];
