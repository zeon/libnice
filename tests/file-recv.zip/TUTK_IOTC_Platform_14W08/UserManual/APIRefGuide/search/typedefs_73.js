var searchData=
[
  ['sessionstatuscb',['sessionStatusCB',['../_i_o_t_c_a_p_is_8h.html#ad12bf90639a802c78bee855dd1054c92',1,'IOTCAPIs.h']]],
  ['sp2ptunnelsessioninfo',['sP2PTunnelSessionInfo',['../_p2_p_tunnel_a_p_is_8h.html#a55f2a7d5fb895a65556a2977d7e97c57',1,'P2PTunnelAPIs.h']]]
];
